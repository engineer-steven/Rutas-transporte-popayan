@echo off
title Microservicio 3 - Monitoreo, Telemetria y Alertas (Puerto 5003)
cd /d "%~dp0\..\microservicios\servicio_monitoreo"

echo ==============================================================================
echo   Iniciando Microservicio 3: Monitoreo, Telemetria y Alertas (REST - 5003)
echo ==============================================================================
echo.

if exist "..\..\venv\Scripts\python.exe" (
    "..\..\venv\Scripts\python.exe" server.py
) else (
    python server.py
)

pause
