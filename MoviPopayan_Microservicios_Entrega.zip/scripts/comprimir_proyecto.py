import os
import zipfile

def compress_project():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    zip_filename = os.path.join(root_dir, "MoviPopayan_Microservicios_Entrega.zip")

    # Carpetas y archivos a excluir del archivo comprimido
    exclude_dirs = {"venv", ".git", ".vscode", "__pycache__"}
    exclude_files = {"MoviPopayan_Microservicios_Entrega.zip"}

    print("==============================================================================")
    print("        COMPRIMIENDO PROYECTO PARA ENTREGA OFICIAL (MOVIPOPAYÁN)")
    print("==============================================================================")
    print(f" Raíz del proyecto: {root_dir}")
    print(f" Archivo destino:   {zip_filename}")
    print(" Excluyendo:        venv/, .git/, .vscode/, __pycache__/\n")

    file_count = 0
    with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
        for dirpath, dirnames, filenames in os.walk(root_dir):
            # Filtrar carpetas excluidas en el recorrido
            dirnames[:] = [d for d in dirnames if d not in exclude_dirs and not d.startswith(".")]

            for filename in filenames:
                if filename in exclude_files or filename.endswith(".pyc"):
                    continue

                full_path = os.path.join(dirpath, filename)
                rel_path = os.path.relpath(full_path, root_dir)
                zipf.write(full_path, rel_path)
                file_count += 1

    zip_size_mb = os.path.getsize(zip_filename) / (1024 * 1024)
    print(f"[OK] Proyecto comprimido exitosamente.")
    print(f"     Archivos empaquetados: {file_count}")
    print(f"     Tamaño del archivo:    {zip_size_mb:.2f} MB")
    print(f"     Ubicación:             {zip_filename}")
    print("==============================================================================\n")

if __name__ == "__main__":
    compress_project()
