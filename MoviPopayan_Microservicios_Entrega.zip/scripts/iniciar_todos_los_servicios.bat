@echo off
title Iniciar los 3 Microservicios de Transporte Popayan
cd /d "%~dp0\.."

echo ==============================================================================
echo       INICIANDO LOS 3 MICROSERVICIOS DE TRANSPORTE PUBLICO DE POPAYAN
echo ==============================================================================
echo.
echo [1/3] Levantando Microservicio 1: Rutas (SOAP - Puerto 8001)...
start "MS1: Rutas (Puerto 8001)" cmd /k "cd microservicios\servicio_rutas && ..\..\venv\Scripts\python.exe server.py"

timeout /t 2 /nobreak >nul

echo [2/3] Levantando Microservicio 2: Operaciones e Incidentes (SOAP - Puerto 8002)...
start "MS2: Operaciones (Puerto 8002)" cmd /k "cd microservicios\servicio_operaciones && ..\..\venv\Scripts\python.exe server.py"

timeout /t 2 /nobreak >nul

echo [3/3] Levantando Microservicio 3: Monitoreo, Calidad y Alertas (REST - Puerto 5003)...
start "MS3: Monitoreo REST (Puerto 5003)" cmd /k "cd microservicios\servicio_monitoreo && ..\..\venv\Scripts\python.exe server.py"

echo.
echo ==============================================================================
echo  Los 3 servidores han sido iniciados en ventanas independientes:
echo    - MS1 Rutas:       http://127.0.0.1:8001/?wsdl
echo    - MS2 Operaciones: http://127.0.0.1:8002/?wsdl
echo    - MS3 Monitoreo:   http://127.0.0.1:5003/
echo ==============================================================================
echo.
pause
