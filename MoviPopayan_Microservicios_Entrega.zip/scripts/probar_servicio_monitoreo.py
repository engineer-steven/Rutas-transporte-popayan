"""
Script de pruebas automatizadas para el Microservicio 3 (REST - Puerto 5003).
Verifica:
  1. Conexión y estado del microservicio.
  2. Validación de seguridad (rechazo con 401 si no hay token ni API Key).
  3. Login exitoso y obtención del JWT y API Key.
  4. Perfil de usuario autenticado.
  5. Ejecución de las 5 funcionalidades no lineales con respuestas estructuradas.
  6. Validación alternativa mediante header 'X-API-Key'.
"""

import sys
import json
import requests

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

BASE_URL = "http://127.0.0.1:5003"

def print_separator(title=""):
    print("\n" + "=" * 76)
    if title:
        print(f" {title}")
        print("=" * 76)

def test_endpoint(name, method, url, headers=None, payload=None, expected_status=200):
    print(f"\n>> [{name}] -> {method} {url}")
    try:
        if method == "GET":
            res = requests.get(url, headers=headers, timeout=5)
        else:
            res = requests.post(url, headers=headers, json=payload, timeout=5)

        status_ok = (res.status_code == expected_status)
        symbol = "[OK]" if status_ok else "[FALLO]"
        print(f"  {symbol} Codigo HTTP: {res.status_code} (Esperado: {expected_status})")
        try:
            body = res.json()
            print("  Respuesta:")
            print("  " + json.dumps(body, indent=4, ensure_ascii=False).replace("\n", "\n  "))
            return body
        except Exception:
            print("  Texto crudo:", res.text)
            return None
    except requests.exceptions.ConnectionError:
        print("  [ERROR]: No se pudo conectar al servidor en http://127.0.0.1:5003/")
        print("     Verifique que el microservicio este corriendo (ejecute server.py o iniciar_servicio_monitoreo.bat)")
        sys.exit(1)
        sys.exit(1)

def main():
    print_separator("PRUEBAS DE INTEGRACIÓN: MICROSERVICIO 3 DE MONITOREO Y ALERTAS (REST)")

    # 1. Healthcheck / raíz
    test_endpoint("1. Raíz / Información del Servicio", "GET", f"{BASE_URL}/", expected_status=200)

    # 2. Prueba de Seguridad: Petición sin token a endpoint protegido (debe fallar con 401)
    print_separator("2. VALIDACIÓN DE SEGURIDAD: INTENTO SIN TOKEN (DEBE RETORNAR 401)")
    test_endpoint(
        "Acceso no autorizado",
        "POST",
        f"{BASE_URL}/api/v1/monitoreo/evaluar-calidad",
        payload={"route_id": 1, "punctuality": 4, "comfort": 4, "driver": 4, "safety": 4},
        expected_status=401
    )

    # 3. Login
    print_separator("3. LOGIN Y GENERACIÓN DE TOKEN JWT")
    login_response = test_endpoint(
        "Login con credenciales admin / admin123",
        "POST",
        f"{BASE_URL}/api/v1/auth/login",
        payload={"username": "admin", "password": "admin123"},
        expected_status=200
    )

    token = login_response["data"]["token"]
    api_key = login_response["data"]["api_key"]
    print(f"\n  🔑 Token JWT obtenido: {token[:35]}...")
    print(f"  🔑 API Key obtenida:   {api_key}")

    auth_headers = {"Authorization": f"Bearer {token}"}
    api_key_headers = {"X-API-Key": api_key}

    # 4. Perfil protegido
    print_separator("4. PERFIL DE USUARIO (VERIFICACIÓN CON BEARER TOKEN)")
    test_endpoint("Consultar Perfil", "GET", f"{BASE_URL}/api/v1/auth/profile", headers=auth_headers, expected_status=200)

    # 5. Funcionalidad 1: Evaluar Calidad
    print_separator("5. FUNCIONALIDAD 1: EVALUAR CALIDAD NO LINEAL DE SERVICIO")
    test_endpoint(
        "Evaluar Calidad de Ruta 1 (Sotracauca)",
        "POST",
        f"{BASE_URL}/api/v1/monitoreo/evaluar-calidad",
        headers=auth_headers,
        payload={
            "route_id": 1,
            "punctuality": 4,
            "comfort": 3,
            "driver": 2,
            "safety": 4,
            "comment": "Demora en hora pico del Barrio Bolívar, pero bus en buen estado"
        },
        expected_status=201
    )

    # 6. Funcionalidad 2: Detección de Sobrecupo
    print_separator("6. FUNCIONALIDAD 2: DETECCIÓN NO LINEAL DE SOBRECUPO")
    test_endpoint(
        "Telemetría Bus TPK-102 con sobrecupo y exceso de velocidad",
        "POST",
        f"{BASE_URL}/api/v1/monitoreo/deteccion-sobrecupo",
        headers=auth_headers,
        payload={
            "route_id": 1,
            "bus_plate": "TPK-102",
            "current_passengers": 25,
            "max_capacity": 19,
            "current_speed": 48.5
        },
        expected_status=200
    )

    # 7. Funcionalidad 3: Estimar Flota Dinámica
    print_separator("7. FUNCIONALIDAD 3: ALGORITMO PREDICTIVO DE DEMANDA Y FLOTA")
    test_endpoint(
        "Simular flota Ruta 1 a las 07:00 AM con lluvia y actividad universitaria",
        "POST",
        f"{BASE_URL}/api/v1/monitoreo/estimar-flota-dinamica",
        headers=auth_headers,
        payload={
            "route_id": 1,
            "hour": 7,
            "is_rainy": True,
            "is_university_day": True,
            "day_of_week": 2
        },
        expected_status=200
    )

    # 8. Funcionalidad 4: Alerta de Seguridad
    print_separator("8. FUNCIONALIDAD 4: MATRIZ DE CRITICIDAD Y PRIORIZACIÓN DE EMERGENCIAS")
    test_endpoint(
        "Reportar Botón de Pánico en Variante Norte",
        "POST",
        f"{BASE_URL}/api/v1/monitoreo/alertas-seguridad",
        headers=auth_headers,
        payload={
            "route_id": 1,
            "bus_plate": "TPK-102",
            "alert_type": "BOTON_PANICO",
            "severity_level": "ALTA",
            "location_landmark": "Variante Norte",
            "description": "Activación preventiva por situación sospechosa en paradero"
        },
        expected_status=201
    )

    # 9. Funcionalidad 5: Ranking Empresarial (probando con API Key en lugar de JWT)
    print_separator("9. FUNCIONALIDAD 5: RANKING EMPRESARIAL (AUTENTICADO CON X-API-KEY)")
    test_endpoint(
        "Ranking y Auditoría de Empresas de Popayán",
        "GET",
        f"{BASE_URL}/api/v1/monitoreo/ranking-empresas",
        headers=api_key_headers,
        expected_status=200
    )

    print_separator("[EXITO] TODAS LAS PRUEBAS DEL MICROSERVICIO 3 COMPLETADAS SATISFACTORIAMENTE")

if __name__ == "__main__":
    main()
