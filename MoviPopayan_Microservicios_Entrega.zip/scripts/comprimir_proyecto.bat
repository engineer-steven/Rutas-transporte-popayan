@echo off
title Comprimir Proyecto para Entrega Oficial
cd /d "%~dp0\.."

if exist "venv\Scripts\python.exe" (
    venv\Scripts\python.exe scripts\comprimir_proyecto.py
) else (
    python scripts\comprimir_proyecto.py
)

pause
