import sys
import os
from flask import Flask, jsonify
from flask_cors import CORS

# Asegurar path local para importaciones directas
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from config import Config
from routes import auth_bp, monitoring_bp

def create_app():
    app = Flask(__name__)
    CORS(app)

    # Registrar blueprints de autenticación y lógica no lineal
    app.register_blueprint(auth_bp)
    app.register_blueprint(monitoring_bp)

    @app.route("/", methods=["GET"])
    def index():
        return jsonify({
            "service": "MICROSERVICIO 3: MONITOREO, TELEMETRÍA, CALIDAD Y ALERTAS",
            "city": "Popayán, Cauca",
            "protocol": "REST / JSON",
            "port": Config.SERVER_PORT,
            "security": "JWT Bearer Token o Header X-API-Key",
            "endpoints": {
                "auth": {
                    "login": "POST /api/v1/auth/login",
                    "profile": "GET /api/v1/auth/profile (Protegido)"
                },
                "logicas_no_lineales_protegidas": {
                    "1_evaluar_calidad": "POST /api/v1/monitoreo/evaluar-calidad",
                    "2_deteccion_sobrecupo": "POST /api/v1/monitoreo/deteccion-sobrecupo",
                    "3_estimar_flota_dinamica": "POST /api/v1/monitoreo/estimar-flota-dinamica",
                    "4_alertas_seguridad": "POST /api/v1/monitoreo/alertas-seguridad",
                    "5_ranking_empresas": "GET /api/v1/monitoreo/ranking-empresas"
                }
            },
            "status": "OPERACIONAL"
        }), 200

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"success": False, "status": 404, "error": "Recurso no encontrado"}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({"success": False, "status": 500, "error": "Error interno del servidor"}), 500

    return app

def main():
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass

    app = create_app()

    print("\n" + "=" * 78)
    print(" [MS3] MICROSERVICIO 3: MONITOREO, TELEMETRIA Y ALERTAS DE TRANSPORTE (REST)")
    print("=" * 78)
    print(f" Servidor escuchando en: http://{Config.SERVER_HOST}:{Config.SERVER_PORT}/")
    print(" Protocolo:              REST / JSON con Seguridad JWT y API Key")
    print(" Base de Datos:          MySQL (movi_popayan_db)")
    print(" Seguridad:              Requiere 'Authorization: Bearer <token>' o 'X-API-Key: <key>'")
    print(" Endpoint de Login:      POST http://{}:{}/api/v1/auth/login".format(Config.SERVER_HOST, Config.SERVER_PORT))
    print(" [!] 5 FUNCIONALIDADES NO LINEALES PROTEGIDAS:")
    print("   1. POST /api/v1/monitoreo/evaluar-calidad       (Calidad multidimensional y quejas)")
    print("   2. POST /api/v1/monitoreo/deteccion-sobrecupo   (Telemetria, saturacion exponencial)")
    print("   3. POST /api/v1/monitoreo/estimar-flota-dinamica (Prediccion demanda por lluvia/Unicauca)")
    print("   4. POST /api/v1/monitoreo/alertas-seguridad     (Criticidad, respuesta y rutas afectadas)")
    print("   5. GET  /api/v1/monitoreo/ranking-empresas      (Score cruzado y auditoria por empresa)")
    print("=" * 78)
    print(" Presione CTRL + C para detener el servidor.\n")

    app.run(host=Config.SERVER_HOST, port=Config.SERVER_PORT, debug=False)

if __name__ == "__main__":
    main()
