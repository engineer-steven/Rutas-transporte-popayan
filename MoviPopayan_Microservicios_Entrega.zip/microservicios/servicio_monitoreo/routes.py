from flask import Blueprint, request, jsonify
from auth import token_required, check_password, generate_token
import repository
from service import MonitoringService

auth_bp = Blueprint("auth", __name__, url_prefix="/api/v1/auth")
monitoring_bp = Blueprint("monitoring", __name__, url_prefix="/api/v1/monitoreo")

# ------------------------------------------------------------------------------
# ENDPOINTS DE AUTENTICACIÓN Y SEGURIDAD
# ------------------------------------------------------------------------------

@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Endpoint de Login.
    Recibe JSON: {"username": "admin", "password": "..."}
    Retorna: Token JWT, API Key y datos de sesión.
    """
    data = request.get_json(silent=True) or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    if not username or not password:
        return jsonify({
            "success": False,
            "status": 400,
            "error": "Petición incompleta",
            "message": "Debe suministrar 'username' y 'password' en el cuerpo JSON."
        }), 400

    user = repository.find_user_by_username(username)
    if not user or not check_password(password, user["password_hash"]):
        return jsonify({
            "success": False,
            "status": 401,
            "error": "Credenciales inválidas",
            "message": "El usuario o la contraseña no coinciden con nuestros registros."
        }), 401

    token = generate_token(user)

    return jsonify({
        "success": True,
        "status": 200,
        "message": "Autenticación exitosa",
        "data": {
            "token": token,
            "token_type": "Bearer",
            "api_key": user["api_key"],
            "user": {
                "id": user["id"],
                "username": user["username"],
                "full_name": user["full_name"],
                "role": user["role"]
            }
        }
    }), 200


@auth_bp.route("/profile", methods=["GET"])
@token_required
def profile(current_user=None):
    """
    Endpoint protegido para verificar la identidad del token activo.
    """
    return jsonify({
        "success": True,
        "status": 200,
        "message": "Perfil autenticado correctamente",
        "user": {
            "id": current_user["id"],
            "username": current_user["username"],
            "full_name": current_user["full_name"],
            "role": current_user["role"],
            "api_key": current_user["api_key"],
            "created_at": str(current_user.get("created_at", ""))
        }
    }), 200


# ------------------------------------------------------------------------------
# LAS 5 FUNCIONALIDADES NO LINEALES DEL MICROSERVICIO DE MONITOREO (PROTEGIDAS)
# ------------------------------------------------------------------------------

# 1. EVALUAR CALIDAD DE SERVICIO
@monitoring_bp.route("/evaluar-calidad", methods=["POST"])
@token_required
def evaluate_quality(current_user=None):
    """
    ENDPOINT 1 (Protegido con JWT / API Key):
    Cálculo no lineal del índice de satisfacción ciudadana y calidad de la ruta.
    JSON esperado:
    {
      "route_id": 1,
      "punctuality": 4,
      "comfort": 3,
      "driver": 5,
      "safety": 4,
      "comment": "Excelente atención en la variante norte"
    }
    """
    data = request.get_json(silent=True) or {}
    try:
        route_id = int(data.get("route_id"))
        punctuality = int(data.get("punctuality"))
        comfort = int(data.get("comfort"))
        driver = int(data.get("driver"))
        safety = int(data.get("safety"))
    except (TypeError, ValueError):
        return jsonify({
            "success": False,
            "status": 400,
            "error": "Parámetros inválidos",
            "message": "Los campos 'route_id', 'punctuality', 'comfort', 'driver' y 'safety' son requeridos y deben ser enteros."
        }), 400

    comment = data.get("comment", "")
    user_id = current_user.get("id") if current_user else None

    try:
        result = MonitoringService.evaluate_service_quality(
            route_id=route_id,
            punctuality=punctuality,
            comfort=comfort,
            driver=driver,
            safety=safety,
            comment=comment,
            user_id=user_id
        )
        return jsonify({
            "success": True,
            "status": 201,
            "message": "Evaluación de calidad procesada y registrada exitosamente",
            "authenticated_as": current_user.get("username"),
            "data": result
        }), 201
    except ValueError as ve:
        return jsonify({"success": False, "status": 400, "error": str(ve)}), 400
    except Exception as ex:
        return jsonify({"success": False, "status": 500, "error": f"Error interno: {str(ex)}"}), 500


# 2. DETECCIÓN NO LINEAL DE SOBRECUPO Y ALERTA DE CAPACIDAD
@monitoring_bp.route("/deteccion-sobrecupo", methods=["POST"])
@token_required
def detect_overcrowding_route(current_user=None):
    """
    ENDPOINT 2 (Protegido con JWT / API Key):
    Detección de sobrecupo con penalización exponencial y factor por velocidad urbana.
    JSON esperado:
    {
      "route_id": 1,
      "bus_plate": "TPK-102",
      "current_passengers": 24,
      "max_capacity": 19,
      "current_speed": 46.5
    }
    """
    data = request.get_json(silent=True) or {}
    try:
        route_id = int(data.get("route_id"))
        bus_plate = str(data.get("bus_plate", ""))
        current_passengers = int(data.get("current_passengers"))
        max_capacity = int(data.get("max_capacity", 19))
        current_speed = float(data.get("current_speed", 30.0))
    except (TypeError, ValueError):
        return jsonify({
            "success": False,
            "status": 400,
            "error": "Parámetros inválidos",
            "message": "Los campos 'route_id', 'bus_plate', 'current_passengers', 'max_capacity' y 'current_speed' son requeridos."
        }), 400

    if not bus_plate:
        return jsonify({"success": False, "status": 400, "error": "El campo 'bus_plate' es obligatorio."}), 400

    try:
        result = MonitoringService.detect_overcrowding(
            route_id=route_id,
            bus_plate=bus_plate,
            current_passengers=current_passengers,
            max_capacity=max_capacity,
            current_speed=current_speed
        )
        return jsonify({
            "success": True,
            "status": 200,
            "message": "Telemetría procesada y diagnóstico de sobrecupo generado",
            "authenticated_as": current_user.get("username"),
            "data": result
        }), 200
    except ValueError as ve:
        return jsonify({"success": False, "status": 400, "error": str(ve)}), 400
    except Exception as ex:
        return jsonify({"success": False, "status": 500, "error": f"Error interno: {str(ex)}"}), 500


# 3. ALGORITMO PREDICTIVO DE DEMANDA Y FRECUENCIA DE FLOTA
@monitoring_bp.route("/estimar-flota-dinamica", methods=["POST"])
@token_required
def estimate_dynamic_fleet_route(current_user=None):
    """
    ENDPOINT 3 (Protegido con JWT / API Key):
    Modelado no lineal de demanda y dimensionamiento de flota por clima y actividad universitaria.
    JSON esperado:
    {
      "route_id": 1,
      "hour": 7,
      "is_rainy": true,
      "is_university_day": true,
      "day_of_week": 2
    }
    """
    data = request.get_json(silent=True) or {}
    try:
        route_id = int(data.get("route_id"))
        hour = int(data.get("hour", 7))
        is_rainy = bool(data.get("is_rainy", False))
        is_university_day = bool(data.get("is_university_day", True))
        day_of_week = int(data.get("day_of_week", 2))
    except (TypeError, ValueError):
        return jsonify({
            "success": False,
            "status": 400,
            "error": "Parámetros inválidos",
            "message": "Los campos 'route_id', 'hour' son requeridos."
        }), 400

    try:
        result = MonitoringService.estimate_dynamic_fleet(
            route_id=route_id,
            hour=hour,
            is_rainy=is_rainy,
            is_university_day=is_university_day,
            day_of_week=day_of_week
        )
        return jsonify({
            "success": True,
            "status": 200,
            "message": "Simulación predictiva de demanda y flota completada con éxito",
            "authenticated_as": current_user.get("username"),
            "data": result
        }), 200
    except ValueError as ve:
        return jsonify({"success": False, "status": 400, "error": str(ve)}), 400
    except Exception as ex:
        return jsonify({"success": False, "status": 500, "error": f"Error interno: {str(ex)}"}), 500


# 4. MATRIZ NO LINEAL DE PRIORIZACIÓN DE EMERGENCIAS
@monitoring_bp.route("/alertas-seguridad", methods=["POST"])
@token_required
def process_emergency_route(current_user=None):
    """
    ENDPOINT 4 (Protegido con JWT / API Key):
    Matriz no lineal de criticidad, tiempo de respuesta y detección de rutas secundarias afectadas.
    JSON esperado:
    {
      "route_id": 1,
      "bus_plate": "TPK-102",
      "alert_type": "BOTON_PANICO",
      "severity_level": "ALTA",
      "location_landmark": "Barrio Bolívar",
      "description": "Intento de asalto frustrado frente al puente peatonal"
    }
    """
    data = request.get_json(silent=True) or {}
    try:
        route_id = int(data.get("route_id"))
        bus_plate = str(data.get("bus_plate", ""))
        alert_type = str(data.get("alert_type", "ACCIDENTE_VIAL"))
        severity_level = str(data.get("severity_level", "MEDIA"))
        location_landmark = str(data.get("location_landmark", "Sector Centro"))
        description = str(data.get("description", "Reporte de emergencia en vía"))
    except (TypeError, ValueError):
        return jsonify({
            "success": False,
            "status": 400,
            "error": "Parámetros inválidos",
            "message": "Debe suministrar 'route_id', 'bus_plate', 'alert_type', 'severity_level', 'location_landmark' y 'description'."
        }), 400

    try:
        result = MonitoringService.process_emergency_alert(
            route_id=route_id,
            bus_plate=bus_plate,
            alert_type=alert_type,
            severity_level=severity_level,
            location_landmark=location_landmark,
            description=description
        )
        return jsonify({
            "success": True,
            "status": 201,
            "message": "Alerta crítica de seguridad procesada y protocolo activado",
            "authenticated_as": current_user.get("username"),
            "data": result
        }), 201
    except ValueError as ve:
        return jsonify({"success": False, "status": 400, "error": str(ve)}), 400
    except Exception as ex:
        return jsonify({"success": False, "status": 500, "error": f"Error interno: {str(ex)}"}), 500


# 5. SCORE MULTIDIMENSIONAL Y RANKING EMPRESARIAL
@monitoring_bp.route("/ranking-empresas", methods=["GET"])
@token_required
def get_company_rankings_route(current_user=None):
    """
    ENDPOINT 5 (Protegido con JWT / API Key):
    Auditoría regulatoria y ranking cruzado de empresas de transporte de Popayán.
    """
    try:
        result = MonitoringService.get_company_rankings()
        return jsonify({
            "success": True,
            "status": 200,
            "message": "Ranking y auditoría empresarial generados exitosamente",
            "authenticated_as": current_user.get("username"),
            "data": result
        }), 200
    except Exception as ex:
        return jsonify({"success": False, "status": 500, "error": f"Error interno: {str(ex)}"}), 500
