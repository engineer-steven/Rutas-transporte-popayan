import math
import repository

class MonitoringService:
    """
    Capa de Lógica de Negocio del Microservicio de Monitoreo, Telemetría,
    Calidad del Servicio y Alertas de Transporte Urbano de Popayán.
    Implementa 5 lógicas no lineales de alta relevancia para el sistema.
    """

    # ==========================================================================
    # FUNCIONALIDAD 1: Evaluación Compuesta y No Lineal de Calidad
    # ==========================================================================
    @staticmethod
    def evaluate_service_quality(route_id: int, punctuality: int, comfort: int,
                                 driver: int, safety: int, comment: str, user_id: int = None) -> dict:
        """
        Calcula un índice multidimensional de calidad percibida (0-100) aplicando
        penalizaciones no lineales de severidad y factores de reincidencia histórica.
        """
        route = repository.find_route_by_id(route_id)
        if not route:
            raise ValueError(f"La ruta con ID {route_id} no existe en el sistema de Popayán.")

        company = route["company"]

        # Validar rangos de notas (1 a 5 estrellas)
        for name, val in [("puntualidad", punctuality), ("confort", comfort),
                          ("atención_conductor", driver), ("seguridad_vial", safety)]:
            if not (1 <= val <= 5):
                raise ValueError(f"El puntaje de '{name}' debe estar entre 1 y 5. Recibido: {val}")

        # 1. Ponderación base porcentual: Puntualidad (30%), Confort (20%), Conductor (25%), Seguridad (25%)
        base_score = (0.30 * punctuality + 0.20 * comfort + 0.25 * driver + 0.25 * safety) * 20.0

        # 2. Penalización no lineal por criticidad en Seguridad o Trato del Conductor:
        # Si la seguridad vial o la conducta es pésima (<= 2), la percepción cae abruptamente de forma no lineal.
        min_critical = min(driver, safety)
        severity_penalty = 0.0
        if min_critical <= 2:
            severity_penalty = 14.5 * math.pow(3.0 - min_critical, 1.4)

        # 3. Factor de reincidencia histórica de la ruta
        historical_ratings = repository.get_recent_ratings_by_route(route_id)
        recurrence_penalty = 0.0
        if historical_ratings:
            poor_reviews = [r for r in historical_ratings if float(r.get("final_score", 100)) < 60.0]
            poor_rate = len(poor_reviews) / len(historical_ratings)
            if poor_rate >= 0.20:
                recurrence_penalty = round(12.0 * poor_rate * math.sqrt(len(historical_ratings)), 2)

        # 4. Cálculo final acotado entre 0 y 100
        final_score = round(max(0.0, min(100.0, base_score - severity_penalty - recurrence_penalty)), 2)

        # 5. Categorización reglamentaria
        if final_score >= 85.0:
            category = "EXCELENTE"
            recommendation = "Ruta y operador con altos estándares de calidad. Mantener incentivos de frecuencia."
        elif final_score >= 70.0:
            category = "BUENO"
            recommendation = "Servicio aceptable. Se sugiere monitorear tiempos de espera en paraderos secundarios."
        elif final_score >= 50.0:
            category = "REGULAR_PLAN_MEJORA"
            recommendation = "Calificación deficiente. Requiere citación a la empresa operadora para revisión de intervalos y capacitación de conductores."
        else:
            category = "CRITICO_SANCIONABLE"
            recommendation = "Alerta regulatoria. Incumplimiento reiterado o riesgo grave de seguridad. Remitir informe a Secretaría de Tránsito de Popayán."

        # Guardar en base de datos
        rating_id = repository.save_service_rating(
            route_id=route_id,
            company=company,
            user_id=user_id,
            punctuality_score=punctuality,
            comfort_score=comfort,
            driver_score=driver,
            safety_score=safety,
            final_score=final_score,
            category=category,
            comment=comment or "Sin comentarios adicionales"
        )

        return {
            "rating_id": rating_id,
            "route_id": route_id,
            "route_code": route["code"],
            "company": company,
            "scores_input": {
                "punctuality": punctuality,
                "comfort": comfort,
                "driver": driver,
                "safety": safety
            },
            "metrics": {
                "base_score": round(base_score, 2),
                "severity_penalty": round(severity_penalty, 2),
                "recurrence_penalty": recurrence_penalty,
                "final_score": final_score
            },
            "category": category,
            "recommendation": recommendation,
            "persisted_in_db": True
        }

    # ==========================================================================
    # FUNCIONALIDAD 2: Detección No Lineal de Sobrecupo y Alerta de Capacidad
    # ==========================================================================
    @staticmethod
    def detect_overcrowding(route_id: int, bus_plate: str, current_passengers: int,
                            max_capacity: int, current_speed: float) -> dict:
        """
        Analiza telemetría en tiempo real: cuando los pasajeros superan la capacidad
        máxima, el índice de riesgo crece exponencialmente y se pondera con la velocidad.
        """
        route = repository.find_route_by_id(route_id)
        if not route:
            raise ValueError(f"La ruta con ID {route_id} no existe en el sistema de Popayán.")

        if current_passengers < 0 or max_capacity <= 0 or current_speed < 0:
            raise ValueError("Los valores de pasajeros, capacidad o velocidad deben ser números positivos válidos.")

        bus_plate = str(bus_plate).strip().upper()
        occupancy_ratio = round(current_passengers / max_capacity, 3)

        # Cálculo no lineal del factor de estrés y riesgo
        if occupancy_ratio <= 0.85:
            # Operación holgada o nominal
            base_risk = occupancy_ratio * 40.0
            status_desc = "Flujo normal de pasajeros dentro del límite autorizado."
            alert_level = "NORMAL"
        elif occupancy_ratio <= 1.00:
            # Ocupación alta pero legal
            base_risk = 34.0 + ((occupancy_ratio - 0.85) / 0.15) * 21.0
            status_desc = "Bus al límite de capacidad sentada/de pie permitida."
            alert_level = "PRECAUCION"
        else:
            # Sobrecupo: crecimiento exponencial del riesgo
            excess_ratio = occupancy_ratio - 1.00
            # Función de saturación exponencial: 55 + 45*(1 - e^(-3.5 * exceso))
            base_risk = 55.0 + 45.0 * (1.0 - math.exp(-3.5 * excess_ratio))
            status_desc = f"Sobrecupo detectado: {current_passengers - max_capacity} pasajeros por encima de la capacidad homologada."
            alert_level = "SOBRECUPO_CRITICO"

        # Multiplicador dinámico por velocidad en zona urbana de Popayán (límite legal: 40 km/h)
        speed_risk_addition = 0.0
        if current_speed > 40.0 and occupancy_ratio >= 0.90:
            speed_delta = current_speed - 40.0
            speed_risk_addition = min(25.0, math.pow(speed_delta / 15.0, 1.3) * 12.0)
            if base_risk + speed_risk_addition >= 85.0:
                alert_level = "INFRACCION_GRAVE_ALTO_RIESGO"
                status_desc += " Conducción con sobrecupo a velocidad superior al límite urbano permitido."

        final_risk_score = round(min(100.0, base_risk + speed_risk_addition), 2)

        # Decisión inteligente de despacho de bus de refuerzo
        stops_count = repository.get_stops_count(route_id)
        reinforcement_needed = (occupancy_ratio >= 1.05) or (occupancy_ratio >= 0.92 and stops_count >= 3)

        # Guardar telemetría
        telemetry_id = repository.save_bus_telemetry(
            route_id=route_id,
            bus_plate=bus_plate,
            current_passengers=current_passengers,
            max_capacity=max_capacity,
            occupancy_ratio=occupancy_ratio,
            current_speed=current_speed,
            risk_level=alert_level,
            reinforcement_needed=reinforcement_needed
        )

        return {
            "telemetry_id": telemetry_id,
            "route_id": route_id,
            "route_code": route["code"],
            "bus_plate": bus_plate,
            "occupancy_stats": {
                "current_passengers": current_passengers,
                "max_capacity": max_capacity,
                "occupancy_percentage": round(occupancy_ratio * 100, 1),
                "excess_passengers": max(0, current_passengers - max_capacity)
            },
            "telemetry_inputs": {
                "speed_kmh": round(current_speed, 1),
                "speed_limit_kmh": 40.0
            },
            "risk_analysis": {
                "base_risk": round(base_risk, 2),
                "speed_risk_penalty": round(speed_risk_addition, 2),
                "final_risk_score": final_risk_score,
                "alert_level": alert_level
            },
            "operational_directive": {
                "reinforcement_bus_required": reinforcement_needed,
                "suggested_action": "Despachar vehículo de apoyo en el próximo intervalo" if reinforcement_needed else "Continuar monitoreo en ruta estándar",
                "status_description": status_desc
            }
        }

    # ==========================================================================
    # FUNCIONALIDAD 3: Algoritmo Predictivo de Demanda y Flota Requerida
    # ==========================================================================
    @staticmethod
    def estimate_dynamic_fleet(route_id: int, hour: int, is_rainy: bool,
                               is_university_day: bool, day_of_week: int = 2) -> dict:
        """
        Modela de forma no lineal la demanda de pasajeros por hora y calcula el
        número óptimo de buses e intervalo de salida en Popayán bajo lluvia y actividad universitaria.
        """
        route = repository.find_route_by_id(route_id)
        if not route:
            raise ValueError(f"La ruta con ID {route_id} no existe en el sistema de Popayán.")

        if not (0 <= hour <= 23):
            raise ValueError(f"La hora debe estar entre 0 y 23. Recibida: {hour}")

        if not (1 <= day_of_week <= 7):
            raise ValueError(f"El día de la semana debe ser entre 1 (Lunes) y 7 (Domingo). Recibido: {day_of_week}")

        stops_count = repository.get_stops_count(route_id)
        if stops_count <= 0:
            stops_count = 4  # Estimación por defecto para Popayán

        # 1. Demanda base por corredor vial según cantidad de paraderos
        base_demand_passengers = stops_count * 24

        # 2. Curva no lineal horaria de Popayán (modelada con picos de tráfico)
        # Pico 1: 06:30 a 08:30 (entrada laboral/escolar)
        # Pico 2: 11:45 a 13:45 (almuerzo/jornada continua)
        # Pico 3: 17:30 a 19:30 (salida laboral)
        if 6 <= hour <= 8:
            hour_factor = 2.15
            peak_label = "HORA_PICO_MANANA"
        elif 12 <= hour <= 13:
            hour_factor = 1.85
            peak_label = "HORA_PICO_MEDIODIA"
        elif 17 <= hour <= 19:
            hour_factor = 2.25
            peak_label = "HORA_PICO_TARDE"
        elif 9 <= hour <= 11 or 14 <= hour <= 16:
            hour_factor = 1.05
            peak_label = "HORA_VALLE_INTERMEDIA"
        elif 20 <= hour <= 22:
            hour_factor = 0.65
            peak_label = "HORA_NOCHE_DESCENSO"
        else:
            hour_factor = 0.25
            peak_label = "HORA_MADRUGADA_MINIMA"

        # 3. Factor por día de la semana (fines de semana bajan movilidad comercial)
        if day_of_week == 6:
            day_factor = 0.75
        elif day_of_week == 7:
            day_factor = 0.45
        else:
            day_factor = 1.00

        # 4. Modificador climático no lineal: En Popayán, las lluvias intensas
        # aumentan la demanda de buses en ~38% y congestionan el tráfico Panamericana
        weather_multiplier = 1.38 if is_rainy else 1.00
        cycle_traffic_delay = 1.25 if is_rainy else 1.00

        # 5. Factor universitario (Unicauca, Colegio Mayor, centros de formación)
        academic_multiplier = 1.28 if (is_university_day and day_of_week <= 5) else 1.00

        # 6. Demanda final proyectada de pasajeros/hora
        projected_passengers_hour = int(round(
            base_demand_passengers * hour_factor * day_factor * weather_multiplier * academic_multiplier
        ))

        # 7. Tiempo de ciclo estimado de la ruta (minutos)
        standard_cycle_minutes = stops_count * 7.5
        adjusted_cycle_minutes = round(standard_cycle_minutes * cycle_traffic_delay, 1)

        # 8. Flota óptima requerida:
        # Capacidad nominal por vehículo colectivo en Popayán ~ 19 pasajeros sentados
        vehicle_capacity = 19
        required_trips_per_hour = projected_passengers_hour / vehicle_capacity
        optimal_buses = max(2, math.ceil((required_trips_per_hour * (adjusted_cycle_minutes / 60.0))))

        # 9. Frecuencia / intervalo de salida óptimo recomendado (minutos)
        if required_trips_per_hour > 0:
            recommended_headway_minutes = max(3, min(25, round(60.0 / required_trips_per_hour)))
        else:
            recommended_headway_minutes = 20

        return {
            "route_id": route_id,
            "route_code": route["code"],
            "simulation_parameters": {
                "hour": hour,
                "day_of_week": day_of_week,
                "is_rainy": is_rainy,
                "is_university_day": is_university_day,
                "traffic_condition": peak_label
            },
            "demand_forecast": {
                "base_passengers_per_stop": 24,
                "total_stops": stops_count,
                "projected_passengers_per_hour": projected_passengers_hour,
                "rain_impact_percentage": 38 if is_rainy else 0,
                "university_impact_percentage": 28 if (is_university_day and day_of_week <= 5) else 0
            },
            "fleet_sizing_results": {
                "recommended_fleet_buses": optimal_buses,
                "optimal_departure_interval_minutes": recommended_headway_minutes,
                "estimated_cycle_time_minutes": adjusted_cycle_minutes,
                "standard_vehicle_capacity": vehicle_capacity
            },
            "operational_recommendation": (
                f"Para la hora {hour:02d}:00 se recomienda operar con {optimal_buses} buses despachando cada {recommended_headway_minutes} minutos. "
                + ("¡Atención: Activar protocolo de contingencia por lluvia en Popayán!" if is_rainy else "Operación en condiciones normales.")
            )
        }

    # ==========================================================================
    # FUNCIONALIDAD 4: Matriz No Lineal de Priorización de Emergencias
    # ==========================================================================
    @staticmethod
    def process_emergency_alert(route_id: int, bus_plate: str, alert_type: str,
                                severity_level: str, location_landmark: str, description: str) -> dict:
        """
        Registra una alerta crítica, calcula su criticidad no lineal combinando
        tipo, severidad y congestión previa, y determina el tiempo máximo de respuesta.
        """
        route = repository.find_route_by_id(route_id)
        if not route:
            raise ValueError(f"La ruta con ID {route_id} no existe en el sistema de Popayán.")

        bus_plate = str(bus_plate).strip().upper()
        alert_type = str(alert_type).strip().upper()
        severity_level = str(severity_level).strip().upper()
        location_landmark = str(location_landmark).strip()
        description = str(description).strip()

        # Validaciones de catálogo
        valid_types = {"BOTON_PANICO", "ACCIDENTE_VIAL", "FALLA_MECANICA", "BLOQUEO_VIA", "ASALTO_VANDALISMO", "DESVIO_EMERGENCIA"}
        if alert_type not in valid_types:
            raise ValueError(f"Tipo de alerta no reconocido. Valores permitidos: {', '.join(sorted(valid_types))}")

        severity_weights = {"BAJA": 25.0, "MEDIA": 50.0, "ALTA": 75.0, "CRITICA": 95.0}
        if severity_level not in severity_weights:
            raise ValueError("Nivel de severidad inválido. Use: 'BAJA', 'MEDIA', 'ALTA' o 'CRITICA'.")

        type_multipliers = {
            "BOTON_PANICO": 1.15,
            "ASALTO_VANDALISMO": 1.12,
            "ACCIDENTE_VIAL": 1.08,
            "BLOQUEO_VIA": 1.05,
            "FALLA_MECANICA": 0.95,
            "DESVIO_EMERGENCIA": 0.90
        }

        # 1. Puntaje base
        base_score = severity_weights[severity_level] * type_multipliers.get(alert_type, 1.0)

        # 2. Factor no lineal de congestión acumulada: consulta incidentes activos en la ruta
        active_incidents = repository.get_active_incidents_count(route_id)
        incident_impact = 10.0 * math.log2(1.0 + active_incidents) if active_incidents > 0 else 0.0

        # Score final de criticidad
        criticality_score = round(min(100.0, base_score + incident_impact), 2)

        # 3. Cálculo de tiempo máximo de respuesta admisible (minutos): función inversa no lineal
        # Crítica (95+) -> 6 a 8 min (despacho urgente)
        # Baja (<30) -> 35 a 45 min
        max_response_time = max(5, int(round(48.0 - (criticality_score / 100.0) * 41.0)))

        # 4. Detección de rutas secundarias afectadas en el mismo hito de Popayán
        intersecting_routes = repository.get_intersecting_routes_by_landmark(location_landmark, exclude_route_id=route_id)
        affected_corridor = [
            {"route_id": r["id"], "code": r["code"], "company": r["company"]}
            for r in intersecting_routes
        ]

        # Guardar en base de datos
        alert_id = repository.save_emergency_alert(
            route_id=route_id,
            bus_plate=bus_plate,
            alert_type=alert_type,
            severity_level=severity_level,
            criticality_score=criticality_score,
            max_response_time_minutes=max_response_time,
            location_landmark=location_landmark,
            description=description
        )

        return {
            "alert_id": alert_id,
            "route_id": route_id,
            "route_code": route["code"],
            "bus_plate": bus_plate,
            "alert_classification": {
                "type": alert_type,
                "severity": severity_level,
                "criticality_score": criticality_score,
                "max_response_time_minutes": max_response_time
            },
            "location": {
                "landmark": location_landmark,
                "affected_intersecting_routes": affected_corridor
            },
            "incident_context": {
                "active_incidents_on_route": active_incidents,
                "incident_penalty_applied": round(incident_impact, 2)
            },
            "action_protocol": {
                "primary_dispatch": "Unidad de Policía / Ambulancia" if criticality_score >= 80 else "Grúa y mecánico de guardia de la empresa",
                "traffic_directive": f"Notificar desvío provisional por vías alternas alrededor de '{location_landmark}'" if len(affected_corridor) > 0 else "Mantener carril derecho habilitado"
            }
        }

    # ==========================================================================
    # FUNCIONALIDAD 5: Score Multidimensional de Desempeño y Ranking Empresarial
    # ==========================================================================
    @staticmethod
    def get_company_rankings() -> dict:
        """
        Cruza métricas de despachos, siniestralidad, valoraciones de usuarios y
        alertas para rankear de forma no lineal a las empresas de Popayán.
        """
        companies = repository.get_all_companies_names()
        if not companies:
            companies = ["Sotracauca", "Transpubenza", "Translibertad", "Transtambo"]

        evaluated_companies = []

        for comp in companies:
            stats = repository.get_company_stats(comp)

            # 1. Tasa de cumplimiento de despachos (0 a 100)
            tot_disp = stats["total_dispatches"]
            if tot_disp > 0:
                dispatch_rate = ((stats["completed_dispatches"] + 0.85 * stats["active_dispatches"]) / tot_disp) * 100.0
            else:
                dispatch_rate = 85.0  # Estimación estándar si no hay datos

            # 2. Índice de siniestralidad e incidentes ponderados
            tot_inc = stats["total_incidents"]
            incident_penalty = 11.5 * math.sqrt(tot_inc) if tot_inc > 0 else 0.0

            # 3. Satisfacción ciudadana (promedio escala 0 a 100)
            user_satisfaction = stats["avg_score"]

            # 4. Penalización no lineal por alertas críticas acumuladas
            high_alerts = stats["high_alerts"]
            alert_penalty = 7.5 * math.pow(high_alerts, 1.25) if high_alerts > 0 else 0.0

            # 5. Score global ponderado:
            # 35% cumplimiento despachos + 40% satisfacción usuarios - penalizaciones
            composite_score = round(max(0.0, min(100.0,
                0.35 * dispatch_rate + 0.40 * user_satisfaction - incident_penalty - alert_penalty
            )), 2)

            # 6. Semáforo de auditoría regulatoria
            if composite_score >= 80.0:
                audit_category = "CATEGORIA_A_EXCELENTE"
                traffic_light = "VERDE"
                audit_status = "Operador modelo. Cumple indicadores de calidad y seguridad."
            elif composite_score >= 65.0:
                audit_category = "CATEGORIA_B_SATISFACTORIO"
                traffic_light = "AMARILLO_VERDOSO"
                audit_status = "Operación estable. Se sugieren mejoras en control de intervalos."
            elif composite_score >= 50.0:
                audit_category = "CATEGORIA_C_OBSERVACION"
                traffic_light = "AMARILLO_PRECAUCION"
                audit_status = "Bajo observación preventiva por quejas o incidentes viales recurrentes."
            else:
                audit_category = "CATEGORIA_D_AUDITORIA_ESPECIAL"
                traffic_light = "ROJO_CRITICO"
                audit_status = "Sujeto a auditoría prioritaria por Secretaría de Movilidad de Popayán."

            evaluated_companies.append({
                "company": comp,
                "composite_score": composite_score,
                "audit_category": audit_category,
                "traffic_light": traffic_light,
                "audit_status": audit_status,
                "breakdown": {
                    "dispatch_efficiency_rate": round(dispatch_rate, 2),
                    "user_satisfaction_avg": round(user_satisfaction, 2),
                    "incident_penalty": round(incident_penalty, 2),
                    "emergency_alert_penalty": round(alert_penalty, 2),
                    "total_routes": stats["total_routes"],
                    "active_dispatches": stats["active_dispatches"],
                    "total_incidents": stats["total_incidents"],
                    "total_reviews": stats["total_reviews"],
                    "high_alerts": stats["high_alerts"]
                }
            })

        # Ordenar por puntaje descendente
        evaluated_companies.sort(key=lambda x: x["composite_score"], reverse=True)

        # Asignar posición en el ranking
        for index, item in enumerate(evaluated_companies, start=1):
            item["ranking_position"] = index
            item["badge"] = "1er Lugar (Oro)" if index == 1 else ("2do Lugar (Plata)" if index == 2 else ("3er Lugar (Bronce)" if index == 3 else "Participante"))

        return {
            "title": "Ranking Oficial de Desempeño Empresarial de Transporte - Popayán",
            "total_companies_evaluated": len(evaluated_companies),
            "leader_company": evaluated_companies[0]["company"] if evaluated_companies else None,
            "rankings": evaluated_companies
        }
