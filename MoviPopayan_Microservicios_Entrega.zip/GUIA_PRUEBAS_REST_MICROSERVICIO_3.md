# 📡 Guía del Microservicio 3: Monitoreo, Telemetría, Calidad y Alertas (REST)

**MoviPopayán - Sistema Integral de Transporte Público**  
**Puerto Asignado:** `5003`  
**Protocolo:** RESTful (JSON)  
**Seguridad:** Autenticación por JSON Web Token (JWT Bearer Token) o Header `X-API-Key`  
**Base de Datos:** MySQL (`movi_popayan_db`)

---

## 🧭 Índice Rápido
1. [Arquitectura y Estructura de Archivos](#-arquitectura-y-estructura-de-archivos)
2. [Autenticación y Seguridad (Login + JWT / API Key)](#-autenticación-y-seguridad)
3. [Las 5 Funcionalidades No Lineales de Alta Relevancia](#-las-5-funcionalidades-no-lineales)
   - [1. Evaluar Calidad Multidimensional de Servicio](#1-evaluar-calidad-multidimensional-de-servicio)
   - [2. Detección No Lineal de Sobrecupo y Estrés de Flota](#2-detección-no-lineal-de-sobrecupo-y-estrés-de-flota)
   - [3. Algoritmo Predictivo de Demanda y Frecuencia Óptima](#3-algoritmo-predictivo-de-demanda-y-frecuencia-óptima)
   - [4. Matriz No Lineal de Priorización de Emergencias](#4-matriz-no-lineal-de-priorización-de-emergencias)
   - [5. Score Multidimensional y Ranking Empresarial](#5-score-multidimensional-y-ranking-empresarial)
4. [Instrucciones de Ejecución y Pruebas Automatizadas](#-instrucciones-de-ejecución)

---

## 🏛️ Arquitectura y Estructura de Archivos

El microservicio 3 se encuentra organizado en la carpeta `microservicios/servicio_monitoreo/` siguiendo el patrón limpio en capas del proyecto:

```text
microservicios/servicio_monitoreo/
├── .env               <- Variables de entorno (puerto 5003, MySQL, llave secreta JWT)
├── config.py          <- Carga tipada de configuración y fallbacks
├── database.py        <- Conexión MySQL con DictCursor y context manager get_cursor()
├── auth.py            <- Generación y verificación de JWT / API Key y decorador @token_required
├── repository.py      <- Consultas SQL nativas a movi_popayan_db
├── service.py         <- Lógica de negocio de las 5 funcionalidades no lineales
├── routes.py          <- Endpoints REST (Flask Blueprints: /api/v1/auth y /api/v1/monitoreo)
└── server.py          <- Servidor ejecutable en http://127.0.0.1:5003/
```

---

## 🔐 Autenticación y Seguridad

Todos los endpoints funcionales del microservicio están estrictamente protegidos mediante el decorador `@token_required`. Permite dos mecanismos de autenticación:

1. **JWT Bearer Token (Recomendado):** Se incluye en el header HTTP:
   ```text
   Authorization: Bearer <TU_TOKEN_JWT>
   ```
2. **API Key Directa:** Se incluye en el header HTTP o como query param:
   ```text
   X-API-Key: popayan-admin-key-2026
   ```

### 👤 Usuarios y Credenciales Disponibles en Base de Datos:

| Usuario | Contraseña | Rol | API Key Asignada |
| :--- | :--- | :--- | :--- |
| `admin` | `admin123` | `ADMIN` | `popayan-admin-key-2026` |
| `operador_popayan` | `operador123` | `OPERADOR` | `popayan-operador-key-2026` |
| `conductor_sotracauca` | `conductor123` | `CONDUCTOR` | `popayan-conductor-key-2026` |
| `ciudadano_cauca` | `pasajero123` | `PASAJERO` | `popayan-pasajero-key-2026` |

---

### Endpoint de Login
- **URL:** `POST http://127.0.0.1:5003/api/v1/auth/login`
- **Petición JSON:**
```json
{
  "username": "admin",
  "password": "admin123"
}
```
- **Respuesta JSON (HTTP 200):**
```json
{
  "success": true,
  "status": 200,
  "message": "Autenticación exitosa",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "Bearer",
    "api_key": "popayan-admin-key-2026",
    "user": {
      "id": 1,
      "username": "admin",
      "full_name": "Administrador del Sistema Popayán",
      "role": "ADMIN"
    }
  }
}
```

---

## ⭐ Las 5 Funcionalidades No Lineales

Todas las rutas a continuación se encuentran bajo el prefijo `/api/v1/monitoreo/` y requieren token de autenticación.

---

### 1. Evaluar Calidad Multidimensional de Servicio
- **Método y URL:** `POST http://127.0.0.1:5003/api/v1/monitoreo/evaluar-calidad`
- **¿Por qué no es lineal?:** Modela la satisfacción ciudadana ponderando puntualidad (30%), confort (20%), conductor (25%) y seguridad (25%). Aplica una **penalización exponencial de severidad** ($14.5 \times (3 - \min(C_s, C_t))^{1.4}$) si la seguridad o el trato al usuario son deficientes ($\le 2$), y consulta la tasa histórica de quejas de la ruta para aplicar un factor de reincidencia acumulativo.
- **Petición JSON:**
```json
{
  "route_id": 1,
  "punctuality": 4,
  "comfort": 3,
  "driver": 2,
  "safety": 4,
  "comment": "Demora en hora pico del Barrio Bolívar, pero bus en buen estado"
}
```
- **Respuesta JSON (HTTP 201):**
```json
{
  "success": true,
  "status": 201,
  "message": "Evaluación de calidad procesada y registrada exitosamente",
  "data": {
    "rating_id": 6,
    "route_code": "RUTA-1",
    "company": "Sotracauca",
    "metrics": {
      "base_score": 65.0,
      "severity_penalty": 14.5,
      "recurrence_penalty": 0.0,
      "final_score": 50.5
    },
    "category": "REGULAR_PLAN_MEJORA",
    "recommendation": "Calificación deficiente. Requiere citación a la empresa operadora para revisión de intervalos y capacitación de conductores."
  }
}
```

---

### 2. Detección No Lineal de Sobrecupo y Estrés de Flota
- **Método y URL:** `POST http://127.0.0.1:5003/api/v1/monitoreo/deteccion-sobrecupo`
- **¿Por qué no es lineal?:** Cuando el aforo supera el 100% de la capacidad legal ($O > 1.0$), el índice de riesgo deja de crecer linealmente y se dispara siguiendo una **curva de saturación exponencial** ($55 + 45 \times (1 - e^{-3.5 \times \text{exceso}})$). Si la velocidad del bus además excede el límite urbano de Popayán ($40 \text{ km/h}$), añade una penalización potencial por velocidad peligrosa, clasificando la alerta como infracción grave y emitiendo directiva automática de bus de refuerzo.
- **Petición JSON:**
```json
{
  "route_id": 1,
  "bus_plate": "TPK-102",
  "current_passengers": 25,
  "max_capacity": 19,
  "current_speed": 48.5
}
```
- **Respuesta JSON (HTTP 200):**
```json
{
  "success": true,
  "status": 200,
  "message": "Telemetría procesada y diagnóstico de sobrecupo generado",
  "data": {
    "bus_plate": "TPK-102",
    "occupancy_stats": {
      "current_passengers": 25,
      "max_capacity": 19,
      "occupancy_percentage": 131.6,
      "excess_passengers": 6
    },
    "risk_analysis": {
      "base_risk": 84.97,
      "speed_risk_penalty": 5.48,
      "final_risk_score": 90.45,
      "alert_level": "INFRACCION_GRAVE_ALTO_RIESGO"
    },
    "operational_directive": {
      "reinforcement_bus_required": true,
      "suggested_action": "Despachar vehículo de apoyo en el próximo intervalo",
      "status_description": "Sobrecupo detectado: 6 pasajeros por encima de la capacidad homologada. Conducción con sobrecupo a velocidad superior al límite urbano permitido."
    }
  }
}
```

---

### 3. Algoritmo Predictivo de Demanda y Frecuencia Óptima
- **Método y URL:** `POST http://127.0.0.1:5003/api/v1/monitoreo/estimar-flota-dinamica`
- **¿Por qué no es lineal?:** Modela la demanda horaria real de Popayán mediante picos asimétricos (mañana, mediodía y tarde). Incorpora dos multiplicadores concurrentes no lineales fundamentales en la ciudad:
  - **Lluvia:** Incrementa la demanda en un $+38\%$ (los ciudadanos evitan caminar o mototaxismo) y reduce la velocidad comercial por congestión en la Panamericana.
  - **Actividad Universitaria (Unicauca / Colegio Mayor):** Incrementa la demanda en $+28\%$ hacia paraderos de facultades.
  Calcula la flota óptima en circuito y los minutos exactos de intervalo entre buses.
- **Petición JSON:**
```json
{
  "route_id": 1,
  "hour": 7,
  "is_rainy": true,
  "is_university_day": true,
  "day_of_week": 2
}
```
- **Respuesta JSON (HTTP 200):**
```json
{
  "success": true,
  "status": 200,
  "message": "Simulación predictiva de demanda y flota completada con éxito",
  "data": {
    "simulation_parameters": {
      "hour": 7,
      "traffic_condition": "HORA_PICO_MANANA",
      "is_rainy": true,
      "is_university_day": true
    },
    "demand_forecast": {
      "projected_passengers_per_hour": 365,
      "rain_impact_percentage": 38,
      "university_impact_percentage": 28
    },
    "fleet_sizing_results": {
      "recommended_fleet_buses": 12,
      "optimal_departure_interval_minutes": 3,
      "estimated_cycle_time_minutes": 37.5
    },
    "operational_recommendation": "Para la hora 07:00 se recomienda operar con 12 buses despachando cada 3 minutos. ¡Atención: Activar protocolo de contingencia por lluvia en Popayán!"
  }
}
```

---

### 4. Matriz No Lineal de Priorización de Emergencias
- **Método y URL:** `POST http://127.0.0.1:5003/api/v1/monitoreo/alertas-seguridad`
- **¿Por qué no es lineal?:** Cruza la gravedad del incidente (`BOTON_PANICO`, `ACCIDENTE_VIAL`, `BLOQUEO_VIA`) con el número de incidentes viales ya activos en la ruta mediante una función logarítmica ($10 \times \log_2(1 + \text{incidentes})$). Calcula el **tiempo máximo de respuesta admisible** mediante una función inversa sigmoidal e identifica automáticamente en la base de datos qué otras rutas de Popayán se cruzan en el mismo punto para emitir desvíos viales preventivos.
- **Petición JSON:**
```json
{
  "route_id": 1,
  "bus_plate": "TPK-102",
  "alert_type": "BOTON_PANICO",
  "severity_level": "ALTA",
  "location_landmark": "Barrio Bolívar",
  "description": "Activación preventiva por situación sospechosa en paradero comercial"
}
```
- **Respuesta JSON (HTTP 201):**
```json
{
  "success": true,
  "status": 201,
  "message": "Alerta crítica de seguridad procesada y protocolo activado",
  "data": {
    "alert_classification": {
      "type": "BOTON_PANICO",
      "severity": "ALTA",
      "criticality_score": 96.25,
      "max_response_time_minutes": 9
    },
    "location": {
      "landmark": "Barrio Bolívar",
      "affected_intersecting_routes": []
    },
    "action_protocol": {
      "primary_dispatch": "Unidad de Policía / Ambulancia",
      "traffic_directive": "Mantener carril derecho habilitado"
    }
  }
}
```

---

### 5. Score Multidimensional y Ranking Empresarial
- **Método y URL:** `GET http://127.0.0.1:5003/api/v1/monitoreo/ranking-empresas`
- **¿Por qué no es lineal?:** Evalúa a las empresas operadoras (*Sotracauca*, *Transpubenza*, *Translibertad*, *Transtambo*) combinando en tiempo real las tablas de despachos, incidentes, valoraciones ciudadanas y alertas críticas. Aplica **penalización sublineal por incidentes** ($11.5 \times \sqrt{\text{incidentes}}$) y **penalización superlineal por alertas de alto riesgo** ($7.5 \times \text{alertas}^{1.25}$), generando un ranking con medallas y semáforo regulatorio oficial para la Secretaría de Movilidad.
- **Respuesta JSON (HTTP 200):**
```json
{
  "success": true,
  "status": 200,
  "message": "Ranking y auditoría empresarial generados exitosamente",
  "data": {
    "title": "Ranking Oficial de Desempeño Empresarial de Transporte - Popayán",
    "total_companies_evaluated": 4,
    "leader_company": "Translibertad",
    "rankings": [
      {
        "ranking_position": 1,
        "company": "Translibertad",
        "composite_score": 78.40,
        "badge": "1er Lugar (Oro)",
        "audit_category": "CATEGORIA_B_SATISFACTORIO",
        "traffic_light": "AMARILLO_VERDOSO",
        "audit_status": "Operación estable. Se sugieren mejoras en control de intervalos."
      },
      {
        "ranking_position": 2,
        "company": "Sotracauca",
        "composite_score": 68.25,
        "badge": "2do Lugar (Plata)",
        "traffic_light": "AMARILLO_VERDOSO"
      }
    ]
  }
}
```

---

## 🚀 Instrucciones de Ejecución

### 1. Iniciar el Microservicio 3 Individualmente:
Doble clic en:
```text
scripts/iniciar_servicio_monitoreo.bat
```
O desde la terminal:
```bash
cd "microservicios\servicio_monitoreo"
..\..\venv\Scripts\python.exe server.py
```

### 2. Iniciar Todos los Microservicios Simultáneamente:
Doble clic en:
```text
scripts/iniciar_todos_los_servicios.bat
```
Abrirá tres consolas simultáneas:
- Puerto `8001`: Microservicio 1 (Rutas - SOAP)
- Puerto `8002`: Microservicio 2 (Operaciones - SOAP)
- Puerto `5003`: Microservicio 3 (Monitoreo, Calidad y Alertas - REST)

### 3. Ejecutar las Pruebas Automatizadas:
```bash
.\venv\Scripts\python.exe scripts\probar_servicio_monitoreo.py
```
Este script prueba el login, la obtención del JWT, la protección ante accesos sin token y la ejecución de cada una de las 5 funcionalidades no lineales.

### 4. Generar el Archivo Comprimido para la Entrega:
Doble clic en:
```text
scripts/comprimir_proyecto.bat
```
Generará automáticamente `MoviPopayan_Microservicios_Entrega.zip` en la raíz del proyecto, excluyendo carpetas pesadas como `venv` y `.git`.
